import * as THREE from './vendor/three/three.module.js';
import {createCat} from './cat-model.js';
const canvas=document.querySelector('#cat-canvas'),status=document.querySelector('#cat-render-status');
let renderer;
try{
 renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor(0x000000,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.3;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(32,1,.1,30);camera.position.set(4.5,2.65,6.1);camera.lookAt(-.2,1.05,0);
 scene.add(new THREE.HemisphereLight(0xfff4de,0x8e806a,2.2));const sun=new THREE.DirectionalLight(0xfff7e8,3.5);sun.position.set(3,6,5);sun.castShadow=true;sun.shadow.mapSize.set(512,512);sun.shadow.camera.left=-3;sun.shadow.camera.right=3;sun.shadow.camera.top=3;sun.shadow.camera.bottom=-3;sun.shadow.normalBias=.025;scene.add(sun);
 const rim=new THREE.DirectionalLight(0xffffff,1.4);rim.position.set(-3,3,-4);scene.add(rim);
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(15,15),new THREE.ShadowMaterial({opacity:.17}));floor.rotation.x=-Math.PI/2;floor.position.y=-.02;floor.receiveShadow=true;scene.add(floor);
 const cat=createCat();scene.add(cat.root);let settings={petAnimation:true,petTailMotion:true,petMoveSpeed:35},motion={walking:false,heading:0},petState={},last=performance.now(),acc=0;
 const resize=()=>{const {width,height}=canvas.getBoundingClientRect();renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();};new ResizeObserver(resize).observe(canvas);resize();
 const snapshot=data=>{settings={...settings,...data?.preferences};petState=data?.petState||{};if(data?.petMotion)motion=data.petMotion;};window.pet.onSnapshot(snapshot);window.pet.snapshot().then(snapshot);window.pet.onPetMotion(value=>motion=value);
 function frame(now){requestAnimationFrame(frame);const dt=(now-last)/1000;last=now;if(document.hidden)return;acc+=dt;if(acc<1/30)return;const elapsed=acc;acc=0;
  const dx=Math.cos(motion.heading),dy=Math.sin(motion.heading)/.207,heading=Math.atan2(-.594*dx+.805*dy,.805*dx+.594*dy);
  cat.animate(elapsed,{animation:settings.petAnimation!==false,walking:motion.walking,heading,tail:settings.petTailMotion!==false,speed:settings.petMoveSpeed,exhausted:petState.state==='exhausted'});renderer.render(scene,camera);
  canvas.dataset.renderer='webgl-3d';canvas.dataset.triangles=String(renderer.info.render.triangles);canvas.dataset.walking=String(motion.walking);canvas.dataset.tail=String(settings.petTailMotion!==false);canvas.dataset.frame=String((Number(canvas.dataset.frame)||0)+1);
 }requestAnimationFrame(frame);status.hidden=true;
 canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();status.hidden=false;status.textContent='3D 画面正在恢复';});canvas.addEventListener('webglcontextrestored',()=>{status.hidden=true;});
 window.addEventListener('pagehide',()=>renderer.dispose());
}catch(error){status.hidden=false;status.textContent='3D 渲染启动失败，请重启应用';canvas.dataset.renderer='error';}
