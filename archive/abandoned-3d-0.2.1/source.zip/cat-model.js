import * as THREE from './vendor/three/three.module.js';
// Original articulated geometry. No raster cat image is used by the renderer.
export function createCat(){
 const root=new THREE.Group(),body=new THREE.Group();root.add(body);
 const fur=new THREE.MeshStandardMaterial({color:0xc19161,roughness:.96}),striped=fur.clone();
 striped.onBeforeCompile=shader=>{
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 furPoint;').replace('#include <begin_vertex>','#include <begin_vertex>\nfurPoint=position;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 furPoint;').replace('#include <color_fragment>',`#include <color_fragment>
   float stripe=sin(furPoint.x*14.0+sin(furPoint.y*6.0)*0.5+furPoint.z*2.0);
   float grain=fract(sin(dot(furPoint.xy+furPoint.z,vec2(127.1,311.7)))*43758.5453);
   diffuseColor.rgb*=mix(0.72,1.0,smoothstep(-0.85,-0.45,stripe))*(0.98+0.04*grain);`);
 };
 const cream=new THREE.MeshStandardMaterial({color:0xf3e4cc,roughness:1}),pink=new THREE.MeshStandardMaterial({color:0xc58c87,roughness:.9}),dark=new THREE.MeshStandardMaterial({color:0x29251f,roughness:.6}),iris=new THREE.MeshPhysicalMaterial({color:0x829e57,roughness:.23,clearcoat:1}),white=new THREE.MeshBasicMaterial({color:0xfff5d9});
 const geometry=new THREE.SphereGeometry(1,28,18);
 function ellipsoid(parent,material,p,s){const mesh=new THREE.Mesh(geometry,material);mesh.position.set(...p);mesh.scale.set(...s);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
 const torso=ellipsoid(body,striped,[-.1,1.13,0],[1.02,.44,.39]);ellipsoid(body,cream,[.18,.96,0],[.72,.25,.35]);
 ellipsoid(body,fur,[-.78,1.1,0],[.48,.48,.39]);ellipsoid(body,fur,[.67,1.22,0],[.4,.48,.34]);
 const head=new THREE.Group();head.position.set(1.0,1.48,0);body.add(head);
 ellipsoid(head,fur,[.04,.05,0],[.41,.39,.36]);ellipsoid(head,cream,[.25,-.15,0],[.29,.23,.285]);
 for(const side of [-1,1]){
  const ear=new THREE.Group();ear.position.set(-.08,.35,side*.255);ear.rotation.x=side*.18;ear.rotation.z=.10;head.add(ear);
  const shape=new THREE.Shape();shape.moveTo(-.17,0);shape.quadraticCurveTo(-.16,.14,-.07,.29);shape.quadraticCurveTo(.09,.22,.18,0);shape.closePath();
  const earGeo=new THREE.ExtrudeGeometry(shape,{depth:.11,bevelEnabled:true,bevelThickness:.045,bevelSize:.035,bevelSegments:3,steps:1,curveSegments:16});
  const outer=new THREE.Mesh(earGeo,fur);outer.rotation.y=Math.PI/2;outer.castShadow=true;ear.add(outer);
  const inner=ellipsoid(ear,pink,[.16,.12,0],[.02,.10,.082]);inner.rotation.x=-.17*side;
  const eye=new THREE.Group();eye.position.set(.302,.125,side*.235);eye.rotation.y=side*-.6;head.add(eye);
  ellipsoid(eye,iris,[0,0,0],[.063,.085,.096]);ellipsoid(eye,dark,[.058,0,0],[.012,.072,.020]);ellipsoid(eye,white,[.071,.028,.023],[.011,.017,.014]);
  eye.userData.blink=true;
  ellipsoid(head,cream,[.335,-.075,side*.12],[.175,.115,.13]);
  for(let i=0;i<4;i++){
   const pts=[new THREE.Vector3(.385,-.08,side*.18),new THREE.Vector3(.47,-.065+i*.025,side*.39),new THREE.Vector3(.44,-.1+i*.055,side*.62)];
   const line=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),10,.005,4,false),cream);head.add(line);
  }
 }
 const nose=ellipsoid(head,pink,[.47,-.04,0],[.054,.04,.073]);nose.rotation.x=Math.PI/4;
 const mouth=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(.453,-.085,-.085),new THREE.Vector3(.464,-.13,0),new THREE.Vector3(.453,-.085,.085)]),12,.008,4,false),dark);head.add(mouth);
 const legs=[];
 for(const [index,x,z] of [[0,.68,.27],[1,.68,-.27],[2,-.76,.28],[3,-.76,-.28]]){
  const hip=new THREE.Group();hip.position.set(x,1.04,z);body.add(hip);
  ellipsoid(hip,fur,[0,-.18,0],[index>1?.20:.13,.34,.13]);
  const knee=new THREE.Group();knee.position.y=-.5;hip.add(knee);ellipsoid(knee,fur,[0,-.22,0],[.095,.30,.095]);
  const foot=new THREE.Group();foot.position.y=-.46;knee.add(foot);ellipsoid(foot,cream,[.08,.005,0],[.19,.10,.13]);
  for(const offset of [-.07,0,.07])ellipsoid(foot,cream,[.19,0,offset],[.06,.065,.048]);
  legs.push({hip,knee,foot,phase:[0,.5,.72,.22][index],hind:index>1});
 }
 const tail=[];let parent=body;
 for(let i=0;i<15;i++){
  const joint=new THREE.Group();joint.position.set(i===0?-1.04:-.13,i===0?1.23:0,0);parent.add(joint);
  tail.push(joint);parent=joint;
 }
 const tailCurve=new THREE.CatmullRomCurve3([new THREE.Vector3(-1,1.2,0),new THREE.Vector3(-2,2,0),new THREE.Vector3(-2.5,2.1,0)]),tailSegments=52,tailRadial=10;
 const tailGeometry=new THREE.TubeGeometry(tailCurve,tailSegments,.08,tailRadial,false),tailMesh=new THREE.Mesh(tailGeometry,fur);tailMesh.castShadow=true;body.add(tailMesh);
 function updateTail(){const matrix=new THREE.Matrix4();tailCurve.points=tail.map(joint=>{joint.updateMatrix();matrix.multiply(joint.matrix);return new THREE.Vector3().setFromMatrixPosition(matrix);});tailCurve.points.push(new THREE.Vector3(-.13,0,0).applyMatrix4(matrix));tailCurve.updateArcLengths();
  const frames=tailCurve.computeFrenetFrames(tailSegments,false),positions=tailGeometry.attributes.position,normals=tailGeometry.attributes.normal;
  for(let i=0;i<=tailSegments;i++){const u=i/tailSegments,p=tailCurve.getPointAt(u),radius=.115*(1-u)*(.88+.12*Math.sin(u*Math.PI))+.014;for(let j=0;j<=tailRadial;j++){const angle=j/tailRadial*Math.PI*2,n=new THREE.Vector3().addScaledVector(frames.normals[i],Math.cos(angle)).addScaledVector(frames.binormals[i],Math.sin(angle)),index=i*(tailRadial+1)+j;positions.setXYZ(index,p.x+radius*n.x,p.y+radius*n.y,p.z+radius*n.z);normals.setXYZ(index,n.x,n.y,n.z);}}
  positions.needsUpdate=true;normals.needsUpdate=true;tailGeometry.computeBoundingSphere();
 }
 let clock=0,phase=0,yaw=0,walkMix=0,blinkIn=3,blinkTime=0,tailIn=0,tailAmplitude=.14,tailTarget=.14,tailPhase=0,tailSpeed=1;const seed=Math.random()*20;
 function animate(dt,state){
  if(!state.animation){root.rotation.y=yaw;return;}
  dt=Math.min(dt,.06);clock+=dt;const walking=state.walking&&!state.exhausted;
  walkMix+=(Number(walking)-walkMix)*Math.min(1,dt*6);phase+=dt*(1.45+(state.speed||35)/100)*Math.PI*2;
  let target=state.heading??0;target=-target;while(target-yaw>Math.PI)target-=Math.PI*2;while(target-yaw< -Math.PI)target+=Math.PI*2;yaw+=(target-yaw)*Math.min(1,dt*3);
  root.rotation.y=yaw;root.rotation.z=THREE.MathUtils.lerp(root.rotation.z,state.exhausted?Math.PI*.42:0,dt*3);root.position.y=state.exhausted?-.4:0;
  torso.scale.y=.44*(1+.01*Math.sin(clock*1.9));body.position.y=Math.sin(phase*2)*.013*walkMix;
  head.rotation.y=Math.sin(clock*.55+seed)*.06*(1-walkMix);head.rotation.z=Math.sin(phase)*.017*walkMix;
  for(const leg of legs){
   const cycle=phase+leg.phase*Math.PI*2,x=Math.cos(cycle)*.24*walkMix,y=-.93+Math.max(0,Math.sin(cycle))*.13*walkMix;
   const distance=Math.min(.955,Math.hypot(x,y)),bend=Math.acos(THREE.MathUtils.clamp((.5*.5+.46*.46-distance*distance)/(2*.5*.46),-1,1));
   const knee=(Math.PI-bend)*(leg.hind?-1:1),base=Math.atan2(x,-y),offset=Math.acos(THREE.MathUtils.clamp((.5*.5+distance*distance-.46*.46)/(2*.5*distance),-1,1));
   leg.hip.rotation.z=base-(leg.hind?-offset:offset);leg.knee.rotation.z=knee;leg.foot.rotation.z=-leg.hip.rotation.z-knee;
  }
  tailIn-=dt;if(tailIn<=0){tailIn=2+Math.random()*5;tailTarget=.045+Math.random()*.17;tailSpeed=.6+Math.random()*.85;}
  tailAmplitude+=(tailTarget-tailAmplitude)*Math.min(1,dt*1.5);tailPhase+=dt*tailSpeed;
  tail.forEach((joint,i)=>{joint.rotation.z=i===0?-.62:-.075+(state.tail?.055*Math.sin(tailPhase*.82-i*.3+seed):0);joint.rotation.y=state.tail?(tailAmplitude*Math.sin(tailPhase-i*.3+seed)+.04*Math.sin(clock*.39+i*.31))*((i+3)/15):0;});
  updateTail();
  blinkIn-=dt;if(blinkIn<=0){blinkTime=.2;blinkIn=2.5+Math.random()*5;}blinkTime=Math.max(0,blinkTime-dt);
  head.children.filter(x=>x.userData.blink).forEach(eye=>eye.scale.y=blinkTime>0?Math.max(.06,Math.abs(blinkTime-.1)*10):1);
 }
 animate(.016,{animation:true,walking:false,tail:true});return {root,animate,legs,tail};
}
